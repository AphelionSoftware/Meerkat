﻿CREATE SCHEMA [Extract]
    AUTHORIZATION [dbo];

