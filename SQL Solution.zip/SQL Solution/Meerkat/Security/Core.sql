﻿CREATE SCHEMA [Core]
    AUTHORIZATION [dbo];



