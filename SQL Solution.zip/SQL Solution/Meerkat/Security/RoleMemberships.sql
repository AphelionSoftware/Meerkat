﻿ALTER ROLE [db_owner] ADD MEMBER [MNEReports];
GO
ALTER ROLE [db_datareader] ADD MEMBER [MNEReports];
GO