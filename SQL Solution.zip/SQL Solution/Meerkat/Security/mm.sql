﻿CREATE SCHEMA [mm]
    AUTHORIZATION [dbo];



