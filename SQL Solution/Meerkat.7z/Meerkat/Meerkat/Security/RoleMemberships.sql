﻿ALTER ROLE [db_owner] ADD MEMBER [PWLAB\mneMeerkatAdmin];


GO
ALTER ROLE [db_owner] ADD MEMBER [PWLAB\mneSPFInstall];


GO
ALTER ROLE [db_owner] ADD MEMBER [PWLAB\mneAdmin];


GO
ALTER ROLE [db_owner] ADD MEMBER [MNEReports];


GO
ALTER ROLE [db_datareader] ADD MEMBER [MNEReports];

