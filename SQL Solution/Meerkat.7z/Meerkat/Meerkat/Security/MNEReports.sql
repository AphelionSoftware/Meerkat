﻿CREATE USER [MNEReports] FOR LOGIN [MNEReports];

