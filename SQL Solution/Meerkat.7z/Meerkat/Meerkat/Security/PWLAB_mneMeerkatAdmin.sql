﻿CREATE USER [PWLAB\mneMeerkatAdmin] FOR LOGIN [PWLAB\mneMeerkatAdmin];

