﻿CREATE USER [PWLAB\mneAdmin] FOR LOGIN [PWLAB\mneAdmin];

